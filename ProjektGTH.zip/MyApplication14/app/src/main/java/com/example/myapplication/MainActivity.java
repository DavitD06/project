package com.example.myapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Models.User;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    Button btnSingIn, btnLogIN;
    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users ;

    RelativeLayout root ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnSingIn = findViewById(R.id.btnSingin);
        btnLogIN = findViewById(R.id.btnRegister);
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        users = db.getReference("Users");
        root = findViewById(R.id.root_element);

        btnLogIN.setOnClickListener(v -> showRegisterWindow());
    }

    private void showRegisterWindow() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Register");
        dialog.setMessage("Enter all data for registration");

        LayoutInflater infater = LayoutInflater.from(this);
        View registerwindows = infater.inflate(R.layout.windows,null);
        dialog.setView(registerwindows);

        final MaterialTextView email = registerwindows.findViewById(R.id.emailField);
        final MaterialTextView password= registerwindows.findViewById(R.id.passField);
        final MaterialTextView name = registerwindows.findViewById(R.id.nameField);
        final MaterialTextView phone = registerwindows.findViewById(R.id.phoneField);

        dialog.setNegativeButton("Back", (dialoginterfeas, which) -> dialoginterfeas.dismiss());
        dialog.setPositiveButton("Log In", (dialoginterfeas, which) -> {
            if(TextUtils.isEmpty(email.getText().toString())){
                Snackbar.make(root, "Еnter your email", Snackbar.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(name.getText().toString())){
                Snackbar.make(root, "Еnter your name", Snackbar.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(phone.getText().toString())){
                Snackbar.make(root, "Еnter your phone number", Snackbar.LENGTH_SHORT).show();
                return;
            }
            if(password.getText().toString().length()< 8 ){
                Snackbar.make(root,"enter password more than 8 characters", Snackbar.LENGTH_SHORT).show();
                return;
            }
            // регистрациа
            auth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                    .addOnSuccessListener(authResult -> {
                        User user = new User();
                        user.setEmail(email.getText().toString());
                        user.setPassword(password.getText().toString());
                        user.setName(name.getText().toString());
                        user.setPhone(phone.getText().toString());

                        users.child(user.getEmail())
                                .setValue(user)
                                .addOnSuccessListener(unused -> Snackbar.make(root,"User added",Snackbar.LENGTH_SHORT).show());
                    });


        });

        dialog.show();


    }
}